import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.*;

public class ds_peak implements Comparable<ds_peak>{
    public double mMZ;
    public double mRT;
    public double mIsoR;
    public int mCharge;
    public double mStartRT;
    public double mEndRT;
    public double mHeight;
    public int mScanNum;
    public double mQuality;

    public ds_peak temP;
    public String rName;
    public String sName;
    public double adjustRT;
    public double height;
    public double area;
    public double noiselevel;
    public int qCoeluted ;
    public int qCharge ;
    public int qShape ;
    public int qPoint ;
    public String isoStr;
    public Double score;
    public int rCount;
    public double qsw;
    public double qslope;
    public double qzigzag;
    public double qsymmetry;
    public double qsharpness;
    public double qTPASR;
    public double qAMB;
    public double qSL;
    public double qNR;
    public double qSNL;
    public double qSNR;
    public double qScore;


    //public TreeMap<ds_peak, Double> scoreMap = new TreeMap<>();
    public List<ds_peak> targetLi = new ArrayList<ds_peak>();
    public List<ds_peak> decoyLi = new ArrayList<ds_peak>();

    public TreeMap<String, ds_peak> rMap = new TreeMap<>(); //儲存 replicate, Key: rName; Value: Peak
    public TreeMap<String, ds_peak> sMap = new TreeMap<>(); //儲存 sample, Key: sName; Value: Peak



    @Override
    public int compareTo(ds_peak o) {
        if(this.mHeight > o.mHeight){
            return 1;
        }
        else if(this.mHeight == o.mHeight){
            return 0;
        }
        else{
            return -1;
        }
    }
}
