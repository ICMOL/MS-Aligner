import org.apache.commons.math3.analysis.interpolation.LoessInterpolator;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;
import java.util.stream.Collectors;

public class align_fdr {
    public void align(ds_param param, TreeMap<String, List<String>> fMap) throws IOException {
        alignPeak a = new alignPeak(param.mzTol, param.rtTol);
        List<Double> scoreLi = new ArrayList<Double>();
        //double min_score = 0.2;

        //metrices.tsv
//        File mfile = new File(param.output + "metricList.tsv");
//        BufferedWriter wrm = new BufferedWriter(new FileWriter(mfile));
//        wrm.write("Shapiro-Wilk value \t Slope \t ZigZagIndex \t Symmetry \t Sharpness \t TPASR \t ApexMaxBoundary \t SignificanceLevel \t SNR \t"); //	 Start_RT(min.) 	 End_RT(min.)
//        wrm.newLine();

        //region perfrom peak alignment in the replicate level
        calculateFDR fdr =new calculateFDR();
        TreeMap<String, List<ds_peak>> AlltrMap = new TreeMap<>();
        for (String str : fMap.keySet())
        {
            List<String> trLi = fMap.get(str);

            //1. Select the reference
            int rIndex = functions.SelectReference(trLi);

            //region 2. Set up reference peaks
            a.NewMap();
            List<ds_peak> refpLi = functions.ReadFile(trLi.get(rIndex));  //,wrm
            List<ds_peak> refcpLi = new ArrayList<>();
            for (int i = 0; i < refpLi.size(); i++)
            {
                if (refpLi.get(i).mCharge > 0)
                {
                    a.CreateAReference(refpLi.get(i), "r");
                    refcpLi.add(refpLi.get(i));
                }
                //else
                //{
                //    allncpLi.add(refpLi.get(i)); //將 reference中 non-charge的peak加入 allncplist
                //}
            }
            //endregion

            //region 3. perform replicate alignment
            for (int t = 0; t < trLi.size(); t++)
            {
                long start = System.currentTimeMillis();
                NumberFormat formatter = new DecimalFormat("#0.00000");

                if (t != rIndex)
                {
                    List<ds_peak> cpLi = new ArrayList<>(); //儲存 charge 的 peak
                    List<ds_peak> ncpLi = new ArrayList<>(); //儲存 non-charge 的 peak
                    List<ds_peak> lkLi = new ArrayList<>(); //儲存 lankmarks

                    List<ds_peak> pLi = functions.ReadFile(trLi.get(t));  //,wrm
                    for(ds_peak p : pLi){
                        if(p.mCharge>0){
                            cpLi.add(p);
                        }
                        else{
                            ncpLi.add(p);
                        }
                    }

                    //determine the score using the EM algorithm & find the landmarks
                    double fscore =  fdr.FindScoreCutoff(refcpLi, cpLi, param.mzTol);
                    scoreLi.add(fscore);
                    for(int i=0; i<refcpLi.size(); i++) {
                        for(ds_peak p : refcpLi.get(i).targetLi) {
                            //double dis = Math.sqrt(Math.pow((refcpLi.get(i).mMZ) - (p.mMZ), 2) + Math.pow((refcpLi.get(i).mRT - p.mRT), 2));
                            double dis = refcpLi.get(i).mRT - p.mRT;
                            double score = (dis==0) ? 9999 : 1 / dis;
                            if (score >= fscore) {
                                refcpLi.get(i).temP = p;
                                lkLi.add(refcpLi.get(i));
                            }

                        }
                    }

                    //perform LOWESS regression (Use the landmarks for LOWESS regression and adjust rt shits)
                    List<Double> refLi = new ArrayList<Double>();
                    List<Double> prtLi = new ArrayList<Double>();
                    for(int i=0; i<lkLi.size(); i++){
                        if(!refLi.contains(lkLi.get(i).mRT) && !prtLi.contains(lkLi.get(i).temP.mRT)){
                            refLi.add(lkLi.get(i).mRT);
                            prtLi.add(lkLi.get(i).temP.mRT);
                        }
                    }
                    double refAry[] = new double[refLi.size()];
                    for(int i=0; i<refLi.size(); i++){
                        refAry[i] = refLi.get(i);
                    }
                    double prtAry[] = new double[prtLi.size()];
                    for(int i=0; i<prtLi.size(); i++){
                        prtAry[i] = prtLi.get(i);
                    }
                    Arrays.sort(refAry);
                    Arrays.sort(prtAry);
                    LoessInterpolator loess = new LoessInterpolator(param.windowsize, 3);
                    double smoothAry[] = loess.smooth(prtAry, refAry);

                    //Adjust the retention time in the aligned peak list
                    adjustRT adj = new adjustRT(prtAry, smoothAry);
                    adj.adjust(cpLi);
                    adj.adjust(ncpLi);

                    //align peaks with charges
                    Collections.sort(cpLi,new Comparator<ds_peak>(){public int compare (ds_peak p1, ds_peak p2)
                    { // sort the peaks on the basis of their intensities in the descending order
                        return (int) ((p1.height)-(p2.height));
                    }});

                    for (int j = 0; j < cpLi.size(); j++)
                    {
                        a.align(cpLi.get(j), "r", fscore);
                    }

                    for (List<ds_peak> tplist : a.pMap.values())
                    { //clean up the temPs
                        for (int j = 0; j < tplist.size(); j++)
                        {
                            ds_peak p = tplist.get(j);
                            p.temP = null;
                        }
                    }

                    //align peaks with the charge of 0
                    Collections.sort(ncpLi,new Comparator<ds_peak>(){public int compare (ds_peak p1, ds_peak p2)
                    {
                        return (int) ((p1.height)-(p2.height));
                    }});
                    for (int i = 0; i < ncpLi.size(); i++)
                    {
                        a.align(ncpLi.get(i), "r", fscore);
                    }

                    long end = System.currentTimeMillis();
                    System.out.println( trLi.get(t) + " finish!\t"+ formatter.format((end - start) / (1000d * 60)) + " min." + "\t cut-off: " + 1/fscore);
                }
            }
            //endregion

            functions.DataIntegration(a.pMap, "r");

            //5. Generate the final peak list
            List<ds_peak> fplist = new ArrayList<>();
            for (List<ds_peak> apd : a.pMap.values()) {
                fplist.addAll(apd);

            }
            a.pMap.clear();
            AlltrMap.put(str, fplist);
//            wrm.close();
        }
        //endregion


        //align peaks across samples
        List<ds_peak> allsncplist = new ArrayList<>();
        String refsName = "";
        //region 1. Select a reference
        int maxCount = 0;
        for (String str : AlltrMap.keySet())
        {
            int pCount = 0;
            List<ds_peak> plist = AlltrMap.get(str);
            for (int i = 0; i < plist.size(); i++)
            {
                if (plist.get(i).mCharge >= 1)
                {
                    pCount += 1;
                }
            }
            if (pCount >= maxCount)
            {
                maxCount = pCount;
                refsName = str;
            }
        }
        //endregion

        //region 2. perform alignment
        a.NewMap();
        List<ds_peak> refpLi = AlltrMap.get(refsName);
        for (int i = 0; i < refpLi.size(); i++)
        {
            if (refpLi.get(i).mCharge >= 1)
            {
                a.CreateAReference(refpLi.get(i), "s");
            }
            else
            {
                allsncplist.add(refpLi.get(i));
            }
        }

        List<String> strKeyLi = AlltrMap.keySet().stream().collect(Collectors.toList());
        Collections.sort(strKeyLi);
        for (int i = 0; i < strKeyLi.size(); i++)
        {
            String sName = strKeyLi.get(i);
            if (sName != refsName)
            {
                List<ds_peak> spLi = AlltrMap.get(strKeyLi.get(i));

                List<ds_peak> cpLi = new ArrayList<>();
                List<ds_peak> ncpLi = new ArrayList<>();
                List<ds_peak> lkLi = new ArrayList<>();

                for(ds_peak p : spLi){
                    if(p.mCharge>0){
                        cpLi.add(p);
                    }
                    else{
                        ncpLi.add(p);
                    }
                }

                double fscore =  fdr.FindScoreCutoff(refpLi, cpLi, param.mzTol);
                scoreLi.add(fscore);
                for(int j=0; j<refpLi.size(); j++) {
                    for(ds_peak p : refpLi.get(j).targetLi) {
                        double dis = Math.sqrt(Math.pow((refpLi.get(j).mMZ) - (p.mMZ), 2) + Math.pow((refpLi.get(j).mRT - p.mRT), 2));
                        //double dis = refcpLi.get(i).mRT - p.mRT;
                        double score = (dis==0) ? 9999 : 1 / dis;
                        if (score >= fscore) {
                            refpLi.get(j).temP = p;
                            lkLi.add(refpLi.get(j));
                        }
                    }
                }

                //Use the landmarks for LOWESS regression and adjust rt shits
                //perform LOWESS regression
                List<Double> refLi = new ArrayList<Double>();
                List<Double> prtLi = new ArrayList<Double>();
                for(int j=0; j<lkLi.size(); j++){
                    if(!refLi.contains(lkLi.get(j).mRT) && !prtLi.contains(lkLi.get(j).temP.mRT)){
                        refLi.add(lkLi.get(j).mRT);
                        prtLi.add(lkLi.get(j).temP.mRT);
                    }
                }
                double refAry[] = new double[refLi.size()];
                for(int j=0; j<refLi.size(); j++){
                    refAry[j] = refLi.get(j);
                }
                double prtAry[] = new double[prtLi.size()];
                for(int j=0; j<prtLi.size(); j++){
                    prtAry[j] = prtLi.get(j);
                }
                Arrays.sort(refAry);
                Arrays.sort(prtAry);
                LoessInterpolator loess = new LoessInterpolator(param.windowsize, 3);
                double smoothAry[] = loess.smooth(prtAry, refAry);

                //Adjust the retention time in the aligned peak list
                adjustRT adj = new adjustRT(prtAry, smoothAry);
                adj.adjust(cpLi);
                adj.adjust(ncpLi);

                Collections.sort(cpLi,new Comparator<ds_peak>(){public int compare (ds_peak p1, ds_peak p2)
                {
                    return (int) ((p1.height)-(p2.height));
                }});
                for (int j = 0; j < cpLi.size(); j++)
                {
                    a.align(cpLi.get(j),"s", fscore);
                }
                for (List<ds_peak> tpLi : a.pMap.values())
                {
                    for (int j = 0; j < tpLi.size(); j++)
                    {
                        ds_peak p = tpLi.get(j);
                        p.temP = null;
                    }
                }

                Collections.sort(ncpLi,new Comparator<ds_peak>(){public int compare (ds_peak p1, ds_peak p2)
                {
                    return (int) ((p1.height)-(p2.height));
                }});
                for (int j = 0; j < allsncplist.size(); j++)
                {
                    a.align(allsncplist.get(j), "s", fscore);
                }
            }
        }

        //endregion

        functions.DataIntegration(a.pMap, "s");

        System.out.println("starting the second merge");

        //region 3. Second Merge (To avoid the border-line situation)
        //a. 將所有 peak 儲存到 allplist, 並且依其 replicate amount 排序
        List<ds_peak> allpLi = new ArrayList<ds_peak>();
        for(List<ds_peak> cpLi : a.pMap.values())
        {
            for (int i = 0; i < cpLi.size(); i++)
            {
                ds_peak cp = cpLi.get(i);
                int rCount = 0;
                for(ds_peak sp : cp.sMap.values())
                {
                    rCount += sp.rMap.size();
                }
                cp.rCount = rCount;
                allpLi.add(cp);
            }
        }
        Collections.sort(allpLi,new Comparator<ds_peak>(){public int compare (ds_peak p1, ds_peak p2)
        {
            return (int) ((p1.rCount)-(p2.rCount));
        }});
        a.pMap.clear();

        //b. 重新分群
        double medscore = functions.TakeMedian(scoreLi);
        mergePeak pm = new mergePeak();
        for (int i = allpLi.size()-1; i >=0 ; i--)
        {
            pm.pMerge(allpLi.get(i), param.mzTol, medscore, param.rtTol);
        }

        //c. 整理資料
        functions.DataIntegration(pm.allpMap, "s");
        allpLi.clear();

        //endregion

        //region 4. Export the aligned result
        //region a. convert the data structure
        for (List<ds_peak> cpLi : pm.allpMap.values())
        {
            for (int i = 0; i < cpLi.size(); i++)
            {
                ds_peak cp = cpLi.get(i);
                int rCount = 0;
                for (ds_peak sp : cp.sMap.values())
                {
                    rCount += sp.rMap.size();
                }
                cp.rCount = rCount;
                allpLi.add(cp);
            }
        }
        a.pMap.clear();
        //endregion

        //region b. export
        BufferedWriter wr = new BufferedWriter(new FileWriter(param.output));
        wr.write("MZ \t RT(min.) \t Start_RT(min.) \t End_RT(min.) \t Charge \t IsotopeRatio \t Score \t");
        if(param.Level==1){
            for(String sName : fMap.keySet()){
                wr.write(sName+"\t");
            }
            wr.newLine();
        }
        else if(param.Level==2){
            for(String sName : fMap.keySet()){
                List<String> fLi = fMap.get(sName);
                for(String fName : fLi){
                    wr.write(fName.substring(fName.lastIndexOf("\\")+1, fName.lastIndexOf(".")) +"\t");
                }
            }
            wr.newLine();
        }

        for(ds_peak p : allpLi){
            boolean is_print = false;

            //check if the peak is detected in at least min_sample
            TreeMap<String, Double> sAbnMap = new TreeMap<String, Double>();
            int count = 0;
            for(String sName : fMap.keySet()){

                double abn = 0;
                if(p.sMap.containsKey(sName)){
                    ds_peak sp = p.sMap.get(sName);
                    List<String> fLi = fMap.get(sName);
                    List<Double> abnLi = new ArrayList<Double>();
                    for(String fName : fLi){

                        if(sp.rMap.containsKey(fName)){

                            ds_peak rp = sp.rMap.get(fName);
                            abnLi.add(rp.area);
                        }
                    }

                    abn = functions.TakeMedian(abnLi);
                }
                if(abn>0){
                    count += 1;
                }
                sAbnMap.put(sName, abn);

            }
            is_print = (count>= param.MinSample) ? true: false;

            //check if the peak is within the given range
            double mass = p.mMZ*(p.mCharge==0?1:p.mCharge);
            double rt = p.mRT/60;
            if((p.mCharge>=param.MinChargeState) && (p.mCharge<=param.MaxChargeState)
                    && (mass>=param.MinMassRange) && (mass<=param.MaxMassRange)
                    && (rt>=param.MinRTRange) && (rt<=param.MaxRTRange)){
                is_print = true;
            }
            else{
                is_print = false;
            }

            if(param.Level==1){
                if(is_print){
                    wr.write(p.mMZ + "\t" + (p.mRT/60) + "\t" + (p.mStartRT/60) + "\t" + (p.mEndRT/60) + "\t" + p.mCharge + "\t" + p.mIsoR + "\t" + p.qScore + "\t");
                    for(String sName : fMap.keySet()){
                        wr.write(sAbnMap.get(sName) + "\t");
                    }
                    wr.newLine();
                }
            }
            else if(param.Level==2){
                if(is_print){
                    wr.write(p.mMZ + "\t" + (p.mRT/60) + "\t" + (p.mStartRT/60) + "\t" + (p.mEndRT/60) + "\t" + p.mCharge + "\t" + p.mIsoR + "\t" + p.qScore + "\t");
                    for(String sName : fMap.keySet()){
                        List<String> fLi = fMap.get(sName);
                        if(p.sMap.containsKey(sName)){
                            ds_peak sp = p.sMap.get(sName);
                            for(String fName : fLi){
                                if(sp.rMap.containsKey(fName)){
                                    ds_peak rp = sp.rMap.get(fName);
                                    wr.write(rp.area + "\t");
                                    //wr.write(rp.mMZ+"_"+rp.mRT + "\t");
                                }
                                else{
                                    wr.write("0\t");
                                }
                            }
                        }
                        else{
                            for(String fName : fLi){
                                wr.write("0\t");
                            }
                        }
                    }
                    wr.newLine();
                }
            }
        }

        wr.close();

        //endregion

        //endregion
    }
}
