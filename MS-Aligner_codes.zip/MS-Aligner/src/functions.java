import java.io.*;
import java.lang.reflect.Array;
import java.nio.charset.StandardCharsets;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class functions {
    public static int SelectReference(List<String> trLi) throws IOException {
        int rIndex = -1; //referenceIndex
        int maxnpCount = 0;

        for (int i = 0; i < trLi.size(); i++)
        {
            int npCount = 0;
            BufferedReader sr = new BufferedReader(new FileReader(trLi.get(i)));
            String line1 = sr.readLine();
            String title = sr.readLine();
            String line = sr.readLine();
            while (line != null)
            {
                String[] strAry = line.split("\t");


                int charge = (int)Double.parseDouble(strAry[4]);

                if (charge > 0)
                {
                    npCount += 1;
                }
                line = sr.readLine();
            }
            if (npCount > maxnpCount)
            {
                maxnpCount = npCount;
                rIndex = i;
            }
            sr.close();
        }

        return rIndex;
    }

    public static List<ds_peak> ReadFile(String fName) throws IOException {  //, BufferedWriter wrm
        List<ds_peak> pLi = new ArrayList<>();
        BufferedReader sr = new BufferedReader(new FileReader(fName));
//        BufferedReader sr = new BufferedReader(new InputStreamReader(new FileInputStream(fName), StandardCharsets.UTF_8));  //指定編碼
        //String[] strAry = fName.split("_" );
        String title = sr.readLine();
        String line1 = sr.readLine();
        double[] metric;
        while (line1 != null) {
            String[] arrline = line1.split("\t");
            ds_peak p = new ds_peak();
            p.rName = fName;
            File file = new File(fName);
            String baseName = file.getName();
//            String baseName = fName.substring(fName.lastIndexOf("\\") + 1);

//            1.
//            int lastUnderscoreIndex = baseName.lastIndexOf("_");
//            if (lastUnderscoreIndex != -1) {
//                p.sName = baseName.substring(0, lastUnderscoreIndex);
//            } else {
//                p.sName = baseName.split("[0-9]")[0];
//            }
//            2. ST1888
//            Pattern pattern = Pattern.compile("^[a-zA-Z]+");
//            Matcher matcher = pattern.matcher(baseName);
//
//            if(matcher.find()){
//                p.sName = matcher.group();
//            }else{
//                p.sName = baseName;
//            }
//            3.
            int doIndex = baseName.lastIndexOf(".");
            if(doIndex != -1){
                baseName = baseName.substring(0,doIndex);
            }

            int lastUnderscoreIndex = baseName.lastIndexOf('_');
            if (lastUnderscoreIndex != -1) {
                String afterUnderscoreIndex = baseName.substring(0,lastUnderscoreIndex);
                p.sName = baseName.substring(0, lastUnderscoreIndex);
//                    System.out.println(afterUnderscoreIndex);
//                if(afterUnderscoreIndex.matches("\\d+")){
//                    p.sName = baseName.substring(0, lastUnderscoreIndex);
//                }else{
//                    p.sName = baseName;
//                }
            } else {
                p.sName = baseName;
            }

            p.mMZ = Float.parseFloat(arrline[0]);
            p.mRT = Float.parseFloat(arrline[1]);
            p.adjustRT = Float.parseFloat(arrline[1]);
            p.mStartRT = Float.parseFloat(arrline[2]);
            p.mEndRT = Float.parseFloat(arrline[3]);
            p.mCharge = (int) Double.parseDouble(arrline[4]);
            //p.mCharge = (int) Double.parseDouble(arrline[4])==0?1:(int) Double.parseDouble(arrline[4]);
            p.height = Float.parseFloat(arrline[5]);
            p.area = Float.parseFloat(arrline[6]);
            p.mIsoR = Float.parseFloat(arrline[7]);
            p.noiselevel = Float.parseFloat(arrline[8]);
            p.mScanNum = (int) Double.parseDouble(arrline[9]);

            p.qsw = Float.parseFloat(arrline[10]);
            p.qslope = Float.parseFloat(arrline[11]);
            p.qzigzag = Float.parseFloat(arrline[12]);
            p.qsymmetry = Float.parseFloat(arrline[13]);
            p.qsharpness = Float.parseFloat(arrline[14]);
            p.qTPASR = Float.parseFloat(arrline[15]);
            p.qAMB = Float.parseFloat(arrline[16]);
            p.qSL = Float.parseFloat(arrline[17]);
//            p.qNR = Float.parseFloat(arrline[18]);
//            p.qSNL = Float.parseFloat(arrline[19]);
            p.qSNR = Float.parseFloat(arrline[18]);
            p.qScore = Float.parseFloat(arrline[19]);
//            System.out.println(p.qScore);

//            metric = new double[]{p.qsw, p.qslope, p.qzigzag, p.qsymmetry,
//                    p.qsharpness, p.qTPASR, p.qAMB, p.qSL, p.qSNR};
//
//            for (Double m : metric) {
//                wrm.write(m + "\t");
//            }
//            wrm.newLine();


            pLi.add(p);
            line1 = sr.readLine();
        }
        sr.close();
        return pLi;

    }


    public static void DataIntegration(TreeMap<Integer, List<ds_peak>> pMap, String level)
    {
        List<Integer> pgrkeylist = new ArrayList<Integer>();
        for(Integer key : pMap.keySet())
        {
            List<ds_peak> pLi = pMap.get(key);
            if (pLi.size() > 0)
            {
                for (int i = 0; i < pLi.size(); i++)
                {
                    ds_peak cp = pLi.get(i);

                    List<Double> mMZLi = new ArrayList<Double>();
                    List<Double> mRTLi = new ArrayList<Double>();
                    List<Double> mHeightLi = new ArrayList<Double>();
                    List<Double> mIsoRLi = new ArrayList<Double>();
                    TreeMap<Integer, Integer> mChargeMap = new TreeMap<Integer, Integer>();
                    List<Double> mStartRTLi = new ArrayList<Double>();
                    List<Double> mEndRTLi = new ArrayList<Double>();
                    List<Integer> mScanNumLi = new ArrayList<Integer>(); //ScanNum
//                    List<Double> mQualityLi = new ArrayList<Double>();
                    List<Double> mScoreLi = new ArrayList<>();

                    if (level == "r")
                    {
                        //region take median in the replicate level

                        for(ds_peak rp : cp.rMap.values())
                        {
                            double rtShift = rp.adjustRT - rp.mRT;
                            double predictRT = rp.mRT + rtShift;
                            double predictStartRT = rp.mStartRT + rtShift;
                            double predictEndRT = rp.mEndRT + rtShift;

                            mMZLi.add(rp.mMZ);
                            mRTLi.add(predictRT);
                            mHeightLi.add(rp.height);
                            mScanNumLi.add(rp.mScanNum);
//                            mQualityLi.add(rp.mQuality);
                            mScoreLi.add(rp.qScore);


                            if (rp.mCharge >= 1) // 避免有 charge 但是 Isotopic Ratio 為0
                            {
                                mIsoRLi.add(rp.mIsoR);
                            }

                            mStartRTLi.add(predictStartRT);
                            mEndRTLi.add(predictEndRT);

                            //charge
                            if (mChargeMap.containsKey(rp.mCharge))
                            {
                                int count = mChargeMap.get(rp.mCharge);
                                count += 1;
                                mChargeMap.remove(rp.mCharge);
                                mChargeMap.put(rp.mCharge, count);
                            }
                            else
                            {
                                mChargeMap.put(rp.mCharge, 1);
                            }
                        }

                        //endregion
                    }
                    else if (level == "s")
                    {
                        //region take the median in the sample level

                        for(ds_peak sp : cp.sMap.values())
                        {
                            for(ds_peak rp : sp.rMap.values())
                            {
                                double rtShift = rp.adjustRT - rp.mRT;
                                double predictRT = rp.mRT + rtShift;
                                double predictStartRT = rp.mStartRT + rtShift;
                                double predictEndRT = rp.mEndRT + rtShift;

                                mMZLi.add(rp.mMZ);
                                mRTLi.add(predictRT);
                                mHeightLi.add(rp.height);
                                mScanNumLi.add(rp.mScanNum);
//                                mQualityLi.add(rp.mQuality);
                                mScoreLi.add(rp.qScore);
                                mStartRTLi.add(predictStartRT);
                                mEndRTLi.add(predictEndRT);

                                //charge
                                if (mChargeMap.containsKey(rp.mCharge))
                                {
                                    int count = mChargeMap.get(rp.mCharge);
                                    count += 1;
                                    mChargeMap.remove(rp.mCharge);
                                    mChargeMap.put(rp.mCharge, count);
                                }
                                else
                                {
                                    mChargeMap.put(rp.mCharge, 1);
                                }
                            }
                        }

                        //endregion
                    }

                    //charge
                    mChargeMap.remove(0); //移除charge = 0
                    int mincount = 0;
                    int bestcharge = 0;
                    for(int z : mChargeMap.keySet())
                    {
                        int count = mChargeMap.get(z);
                        if (count > mincount)
                        {
                            mincount = count;
                            bestcharge = z;
                        }
                    }

                    if (level == "s")
                    {
                        for(ds_peak sp : cp.sMap.values())
                        {
                            for(ds_peak rp : sp.rMap.values())
                            {
                                if ((rp.mCharge == bestcharge) &&( bestcharge>0))
                                {
                                    mIsoRLi.add(rp.mIsoR);
                                }
                            }
                        }
                    }

                    DecimalFormat df2 = new DecimalFormat("#.00");
                    DecimalFormat df4 = new DecimalFormat("#.0000");
                    cp.mMZ = TakeMedian(mMZLi);
                    cp.mRT = TakeMedian(mRTLi);
                    cp.adjustRT = TakeMedian(mRTLi);
                    cp.mIsoR = TakeMedian(mIsoRLi);
                    cp.mCharge = bestcharge;
                    cp.mStartRT = TakeMedian(mStartRTLi);
                    cp.mEndRT = TakeMedian(mEndRTLi);
                    cp.mHeight = TakeMedian(mHeightLi);
                    cp.mScanNum = TakeMedian1(mScanNumLi);
//                    cp.mQuality = Double.parseDouble(df.format(TakeMedian(mQualityLi)));
                    cp.qScore = Double.parseDouble(df2.format(TakeMedian(mScoreLi)));
                }
            }
            else
            {
                pgrkeylist.add(key);
            }
        }
        for (int i = 0; i < pgrkeylist.size(); i++)
        {
            pMap.remove(pgrkeylist.get(i));
        }
    }

    public static double TakeAvg(List<Double> tmpLi){
        double average = 0;
        for(double score:tmpLi){
            average += score;
        }
        average = average/(tmpLi.size());
        return average;
    }


    public static double TakeMedian(List<Double> tmpLi)
    {
        Collections.sort(tmpLi);
        double mValue;
        if(tmpLi.size() == 0)
        {
            mValue = -9999;
        }
        else if(tmpLi.size() == 1)
        {
            mValue = tmpLi.get(0);
        }
        else if(tmpLi.size() == 2)
        {
            mValue = (tmpLi.get(0)+tmpLi.get(1))/2;
        }
        else
        {
            int mod = tmpLi.size()%2;
            int i1= tmpLi.size()/2;
            if(mod==0) //even
            {
                int i2 = i1-1;
                mValue = (tmpLi.get(i1) + tmpLi.get(i2))/2 ;
            }
            else //odd
            {
                mValue = tmpLi.get(i1);
            }
        }

        return mValue;
    }

    public static int TakeMedian1(List<Integer> tmpLi)
    {
        Collections.sort(tmpLi);
        int mValue;
        if(tmpLi.size() == 0)
        {
            mValue = -9999;
        }
        else if(tmpLi.size() == 1)
        {
            mValue = tmpLi.get(0);
        }
        else if(tmpLi.size() == 2)
        {
            mValue = (tmpLi.get(0)+tmpLi.get(1))/2;
        }
        else
        {
            int mod = tmpLi.size()%2;
            int i1= tmpLi.size()/2;
            if(mod==0) //even
            {
                int i2 = i1-1;
                mValue = (tmpLi.get(i1) + tmpLi.get(i2))/2 ;
            }
            else //odd
            {
                mValue = tmpLi.get(i1);
            }
        }

        return mValue;
    }


}
