import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.TransformerException;
import java.io.*;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class main {
    public static void main(String[] args) throws IOException, ParserConfigurationException, TransformerException {
        ds_param param = new ds_param();
        TreeMap<String, List<String>> fMap =new TreeMap<>();

        //region read/check yml file
        File ymlf = new File(args[0]);
        if(ymlf.exists()){
            param.readyml(args[0]);
        }
        else{
            System.out.println("Please provide the parameter yml file.");
            System.exit(1);
        }
        //endregion

        //region setup input files (samples and technical replicates)
        for (int i = 1; i < args.length; i++) {
            File input = new File(args[i]);

            if (input.isDirectory()) {
                File[] txtFiles = input.listFiles((dir, name) -> name.toLowerCase().endsWith(".txt"));
                if (txtFiles != null) {
                    for (File file : txtFiles) {
                        processFile(file, fMap);
                    }
                }
            } else if (input.isFile()) {
                processFile(input, fMap);
            } else {
                System.out.println("Invalid input: " + args[i]);
            }
        }


        if(!Files.exists(Path.of(param.output))){
            Files.createDirectories(Path.of(param.output));
        }

        //endregion
        if(param.usefdr){
            align_fdr afdr = new align_fdr();
            afdr.align(param, fMap);
        }
        else{
            align_rt art = new align_rt();
            art.align(param, fMap);
        }

        System.out.println("Finish!!!");
    }


    private static void processFile(File file, Map<String, List<String>> fMap) {
        String filepath = file.getName();
        String sname = "";

        int dotIndex = filepath.lastIndexOf(".");
        if (dotIndex != -1) {
            filepath = filepath.substring(0, dotIndex);
        }

        int lastUnderscoreIndex = filepath.lastIndexOf('_');
        if (lastUnderscoreIndex != -1) {
            sname = filepath.substring(0, lastUnderscoreIndex);
        } else {
            sname = filepath;
        }

        fMap.computeIfAbsent(sname, k -> new ArrayList<>()).add(file.getAbsolutePath());
    }
}
