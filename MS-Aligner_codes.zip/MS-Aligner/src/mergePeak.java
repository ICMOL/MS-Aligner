import java.util.*;
import java.util.stream.Collectors;

public class mergePeak {
    public TreeMap<Integer, List<ds_peak>> allpMap = new TreeMap<>();
    public void pMerge(ds_peak p, double mzTol, double score, double rtTol)
    {
        List<Integer> KeyLi = allpMap.keySet().stream().collect(Collectors.toList());
        Collections.sort(KeyLi);

        //1. 找合適的mz bin
        List<Integer> index = FindMZBin(p, KeyLi);

        //2. 找合適的peak cluster
        if(rtTol<0){
            FindBestP_fdr(p, index, mzTol, KeyLi, score);
        }
        else{
            FindBestP_rt(p, index, mzTol, KeyLi, rtTol);
        }
    }

    public void FindBestP_rt(ds_peak p, List<Integer> index, double mzTol, List<Integer> KeyLi, double rtTol)
    {
        double mindis = 1000000;
        ds_peak bestp = null;
        for (int i = 0; i < index.size(); i++){
            if (index.get(i) > -1){
                List<ds_peak> plist = (List<ds_peak>)allpMap.get(KeyLi.get(index.get(i)));
                for (int j = 0; j < plist.size(); j++){
                    ds_peak cp = plist.get(j);

                    if((Math.abs(p.mMZ - cp.mMZ) <= mzTol)&&(Math.abs(p.adjustRT - cp.adjustRT) <= rtTol))
                    {
                        double distance = Math.sqrt(Math.pow(p.mMZ - cp.mMZ, 2) + Math.pow((p.adjustRT - cp.adjustRT) , 2));
                        if (distance <= mindis)
                        {
                            mindis = distance;
                            bestp = cp;
                        }
                    }
                }
            }
        }

        if (bestp != null){
            for (String sName : p.sMap.keySet()){
                ds_peak sp = p.sMap.get(sName);
                if (!bestp.sMap.containsKey(sName)){
                    bestp.sMap.put(sName, sp);
                }
                else{
                    ds_peak csp = bestp.sMap.get(sName);
                    for (String rName : sp.rMap.keySet()){
                        ds_peak rp = sp.rMap.get(rName);
                        if (!csp.rMap.containsKey(rName)){
                            csp.rMap.put(rName, rp);
                        }
                        else{
                            ds_peak crp = (ds_peak)csp.rMap.get(rName);

                            //應該要以 height 高的 peak 為主
                            if (crp.height < rp.height)
                            {
                                crp.mMZ = rp.mMZ;
                                crp.mRT = rp.mRT;
                                crp.adjustRT = rp.adjustRT;
                                crp.mCharge = rp.mCharge;
                                crp.mIsoR = rp.mIsoR;
                                crp.height = rp.height;
                                crp.mStartRT = rp.mStartRT;
                                crp.mEndRT = rp.mEndRT;
                                crp.area = rp.area;
                            }
                        }
                    }
                }
            }
        }
        else
        {
            AddaPeak(p);
        }
    }

    public void FindBestP_fdr(ds_peak p, List<Integer> index, double mzTol, List<Integer> KeyLi, double score)
    {
        //找最合適的 peak group
        double mindistance = 1000000;
        ds_peak bestp = null;
        //ds_paPeak bestp = p.temP;
        for (int i = 0; i < index.size(); i++)
        {
            if (index.get(i) > -1) //代表可能的m/z bin
            {
                List<ds_peak> plist = (List<ds_peak>)allpMap.get(KeyLi.get(index.get(i)));
                for (int j = 0; j < plist.size(); j++)
                {
                    ds_peak cp = plist.get(j);

                    if ((Math.sqrt(Math.pow(p.mMZ - cp.mMZ, 2) + Math.pow((p.mRT - cp.mRT) , 2))>=score))
                    {
                        double distance = Math.sqrt(Math.pow(p.mMZ - cp.mMZ, 2) + Math.pow((p.mRT - cp.mRT) , 2));
                        if (distance <= mindistance)
                        {
                            mindistance = distance;
                            bestp = cp;
                        }
                    }
                }
            }
        }
        if (bestp != null)
        {
            for (String sName : p.sMap.keySet())
            {
                ds_peak sp = p.sMap.get(sName);

                if (!bestp.sMap.containsKey(sName)) //不包含此 sample, 則直接新增
                {
                    bestp.sMap.put(sName, sp);
                }
                else
                {
                    ds_peak csp = bestp.sMap.get(sName);
                    for (String rName : sp.rMap.keySet())
                    {
                        ds_peak rp = sp.rMap.get(rName);
                        if (!csp.rMap.containsKey(rName)) //不包含此 replicate, 則直接新增
                        {
                            csp.rMap.put(rName, rp);
                        }
                        else
                        {
                            ds_peak crp = (ds_peak)csp.rMap.get(rName);

                            //應該要以 height 高的 peak 為主
                            if (crp.height < rp.height)
                            {
                                crp.mMZ = rp.mMZ;
                                crp.mRT = rp.mRT;
                                crp.adjustRT = rp.adjustRT;
                                crp.mCharge = rp.mCharge;
                                crp.mIsoR = rp.mIsoR;
                                crp.height = rp.height;
                                crp.mStartRT = rp.mStartRT;
                                crp.mEndRT = rp.mEndRT;
                                crp.area = rp.area;
                            }
                        }
                    }
                }
            }
        }
        else
        {
            AddaPeak(p);
        }
    }

    public void AddaPeak(ds_peak p)
    {
        if (allpMap.containsKey((int)(p.mMZ)))
        {
            List<ds_peak> plist = (List<ds_peak>)allpMap.get((int)(p.mMZ));
            plist.add(p);
        }
        else
        {
            List<ds_peak> plist = new ArrayList<>();
            plist.add(p);
            allpMap.put((int)(p.mMZ), plist);
        }
    }

    public List<Integer> FindMZBin(ds_peak p, List<Integer> KeyLi)
    {
        List<Integer> index = new ArrayList<>(); //儲存index
        int a2 = KeyLi.indexOf((int)(p.mMZ));
        if (a2 == -1) //代表 Dictionary 中沒有此 key 值, 要確認是否有包含 -1 or +1, 避免進位問題
        {
            a2 = KeyLi.indexOf((int)(p.mMZ) + 1);
        }
        if (a2 == -1)
        {
            a2 = KeyLi.indexOf((int)(p.mMZ) - 1);
        }
        int a1 = -1;
        int a3 = -1;
        if ((a2 > 1) && (a2 < (KeyLi.size() - 1))) //a2在範圍內
        {
            a1 = a2 - 1;
            a3 = a2 + 1;
        }
        index.add(a1);
        index.add(a2);
        index.add(a3);

        for (int i = 0; i < index.size(); i++)
        {
            if (index.get(i) > -1)
            {
                int dif = Math.abs(KeyLi.get(index.get(i)) - (int)(p.mMZ));
                if (dif >= 3) //超過進位的可能
                {
                    index.set(i,-1);
                }
            }
        }

        return index;
    }
}
