import com.sun.security.auth.module.NTSystem;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.security.Key;
import java.util.*;
import java.util.stream.Collectors;

public class alignPeak {

    private double _mzTol = -1;
    private double _rtTol = -1;

    public alignPeak(double mzTol, double rtTol){
        this._mzTol = mzTol;
        this._rtTol = rtTol;
    }

    public TreeMap<Integer, List<ds_peak>> pMap = null;

    public void NewMap() {
        pMap = new TreeMap<>();
    }

    public void CreateAReference(ds_peak p, String level) {
        ds_peak newp = new ds_peak();
        newp.mMZ = p.mMZ;
        newp.mRT = p.mRT;
        newp.adjustRT = p.adjustRT;
        newp.mIsoR = p.mIsoR;
        newp.mCharge = p.mCharge;
        newp.mStartRT = p.mStartRT;
        newp.mEndRT = p.mEndRT;
        newp.rName = p.rName;
        newp.sName = p.sName;

        if (level == "r") {
            newp.rMap.put(p.rName, p);

        } else if (level == "s") {
            newp.sMap.put(p.sName, p);

        }

        if (pMap.containsKey((int)(newp.mMZ))) {
            List<ds_peak> plist = pMap.get((int)(newp.mMZ));
            plist.add(newp);
        } else {
            List<ds_peak> plist = new ArrayList<>();
            plist.add(newp);
            pMap.put((int)(newp.mMZ), plist);
        }
    }

    public List<Integer> FindMZBin(ds_peak p, List<Integer> KeyLi) {
        List<Integer> index = new ArrayList<>(); //儲存index
        int a2 = KeyLi.indexOf((int)(p.mMZ));
        //System.out.println(a2);
        if (a2 == -1) //代表 Dictionary 中沒有此 key 值, 要確認是否有包含 -1 or +1, 避免進位問題
        {
            a2 = KeyLi.indexOf((int)(p.mMZ) + 1);
        }
        if (a2 == -1) {
            a2 = KeyLi.indexOf((int)(p.mMZ) - 1);
        }
        //System.out.println(a2);
        int a1 = -1;
        int a3 = -1;
        if ((a2 > 1) && (a2 < (KeyLi.size() - 1))) //a2在範圍內
        {
            a1 = a2 - 1;
            a3 = a2 + 1;
        }
        index.add(a1);
        index.add(a2);
        index.add(a3);

        //System.out.println((int)p.mMZ);
        for (int i = 0; i < index.size(); i++) {
            if (index.get(i)> -1) {
                //System.out.println(index.get(i));
                int dif = Math.abs(KeyLi.get(index.get(i)) - (int)(p.mMZ));
                if (dif >= 3) //超過進位的可能
                {
                    index.set(i,-1);
                }
            }
        }

        return index;
    }

    public void CoarseMatch(ds_peak p, String level) {

        List<Integer> KeyLi = pMap.keySet().stream().collect(Collectors.toList());
        Collections.sort(KeyLi);

        //1. 找合適的mz bin
        List<Integer> index = FindMZBin(p, KeyLi);
        //2. 找合適的peak cluster
        FindLandmark(p, index, KeyLi, level);

    }
    public void FindLandmark(ds_peak p, List<Integer> index, List<Integer> KeyLi, String level) {
        //找最合適的 peak group
        double mindistance = 1000000;
        ds_peak bestp = null;
        for (int i = 0; i < index.size(); i++) {
            if (index.get(i) > -1) //代表可能的m/z bin
            {
                List<ds_peak> plist = pMap.get(KeyLi.get(index.get(i)));
                for (int j = 0; j < plist.size(); j++) {
                    ds_peak cp = plist.get(j);

                    double mzdiff1 = Math.abs(cp.mMZ - p.mMZ);
                    double maxMZtol = this._mzTol * 3;
                    if (mzdiff1 <= maxMZtol)  //mz有在範圍中
                    {
                        double distance = 0;
                        if (level == "r") {
                            distance = Math.sqrt(Math.pow(p.mMZ - cp.mMZ, 2) + Math.pow((p.mRT - cp.mRT) / 60, 2));

                        } else if (level == "s") {
                            distance = Math.sqrt(Math.pow((p.mMZ - cp.mMZ), 2) + Math.pow((p.mRT - cp.mRT) / 60, 2) + Math.pow((p.mIsoR - cp.mIsoR), 2));
                        }
                        if (distance <= mindistance) {
                            mindistance = distance;
                            bestp = cp;
                        }

                    }
                }
            }
        }
        if (bestp != null) {
            if (bestp.temP != null) {
                double d1 = 0;
                double d2 = 0;
                if (level == "r") {
                    d1 = Math.sqrt(Math.pow(p.mMZ - bestp.mMZ, 2) + Math.pow((p.mRT - bestp.mRT) / 60, 2));
                    d2 = Math.sqrt(Math.pow(bestp.temP.mMZ - bestp.mMZ, 2) + Math.pow((bestp.temP.mRT - bestp.mRT) / 60, 2));
                } else if (level == "s") {
                    d1 = Math.sqrt(Math.pow(p.mMZ - bestp.mMZ, 2) + Math.pow((p.mRT - bestp.mRT) / 60, 2) + Math.pow(p.mIsoR - bestp.mIsoR, 2));
                    d2 = Math.sqrt(Math.pow(bestp.temP.mMZ - bestp.mMZ, 2) + Math.pow((bestp.temP.mRT - bestp.mRT) / 60, 2) + Math.pow(bestp.temP.mIsoR - bestp.mIsoR, 2));
                }

                if (d1 <= d2) {
                    bestp.temP.temP = null;
                    bestp.temP = p;
                    p.temP = bestp;
                }
            } else {
                bestp.temP = p;
                p.temP = bestp;
            }
        }
    }

    public void align(ds_peak p, String level, double score) throws IOException {
        List<Integer> KeyLi =pMap.keySet().stream().collect(Collectors.toList());
        Collections.sort(KeyLi);

        //1. 找合適的mz bin
        List<Integer> index = FindMZBin(p, KeyLi);

        //2. 找合適的peak cluster
        AssignP(p, index, KeyLi, level, score);

    }

    public ds_peak FindBestP(ds_peak p, List<Integer> index, List<Integer> KeyLi, String level, double score) {
        ds_peak bestp = null;

        if(this._rtTol <0){ //use fdr score
            double maxscore = -1;
            for (int i = 0; i < index.size(); i++) {
                if (index.get(i) > -1) {
                    List<ds_peak> plist = pMap.get(KeyLi.get(index.get(i)));
                    for (int j = 0; j < plist.size(); j++) {
                        ds_peak cp = plist.get(j);
                        if(Math.abs(p.mMZ - cp.mMZ) <= this._mzTol){
                            double s = 1/Math.sqrt(Math.pow(p.mMZ - cp.mMZ, 2) + Math.pow((p.adjustRT - cp.adjustRT), 2));
                            if((s>=score) && (s>maxscore)){
                                maxscore = s;
                                bestp = cp;
                            }
                        }
                    }
                }
            }
        }
        else{
            double mindis = 9999;
            for (int i = 0; i < index.size(); i++) {
                if (index.get(i) > -1) {
                    List<ds_peak> plist = pMap.get(KeyLi.get(index.get(i)));
                    for (int j = 0; j < plist.size(); j++) {
                        ds_peak cp = plist.get(j);
                        if((Math.abs(p.mMZ - cp.mMZ) <= this._mzTol)&&(Math.abs(p.adjustRT - cp.adjustRT) <= this._rtTol)){
                            double dis = Math.sqrt(Math.pow(p.mMZ - cp.mMZ, 2) + Math.pow((p.adjustRT - cp.adjustRT), 2));
                            if(dis< mindis){
                                mindis = dis;
                                bestp = cp;
                            }
                        }
                    }
                }
            }
        }

        return bestp;
    }

    public void AssignP(ds_peak p, List<Integer> index, List<Integer> KeyLi, String level, double score) throws IOException {
        ds_peak bestp = FindBestP(p, index, KeyLi, level, score);

        if (level == "r") {
            if (bestp != null) {
                if (!bestp.rMap.containsKey(p.rName)) {
                    bestp.rMap.put(p.rName, p);
                } else //代表此peak可能是被分裂開的, 將兩個peak合併
                {
                    ds_peak cp = bestp.rMap.get(p.rName);
                    ds_peak newcp = MergePeak(cp, p);
                    bestp.rMap.remove(p.rName);
                    bestp.rMap.put(p.rName, newcp);
                }
            } else {
                CreateAReference(p, "r");
            }
        } else if (level == "s") {
            if (bestp != null) {
                if (!bestp.sMap.containsKey(p.sName)) {
                    bestp.sMap.put(p.sName, p);
                } else //代表此peak可能是被分裂開的, 將兩個peak合併
                {
                    ds_peak cp =  bestp.sMap.get(p.sName);
                    ds_peak newcp = MergePeak(cp, p);
                    bestp.sMap.remove(p.sName);
                    bestp.sMap.put(p.sName, newcp);
                }
            } else {
                CreateAReference(p, "s");
            }
        }
    }

    public ds_peak MergePeak(ds_peak cp, ds_peak p) {
        //應該要以 height 高的 peak 為主
        if (p.height > cp.height) {
            cp.mMZ = p.mMZ;
            cp.mRT = p.mRT;
            cp.adjustRT = p.adjustRT;
            cp.mCharge = p.mCharge;
            cp.mIsoR = p.mIsoR;
            cp.height = p.height;
            cp.mStartRT = p.mStartRT;
            cp.mEndRT = p.mEndRT;
            cp.area = p.area;
            cp.qsw = p.qsw;
            cp.qslope = p.qslope;
            cp.qzigzag = p.qzigzag;
            cp.qsymmetry = p.qsymmetry;
            cp.qsharpness = p.qsharpness;
            cp.qTPASR = p.qTPASR;
            cp.qAMB = p.qAMB;
            cp.qSL = p.qSL;
            cp.qNR = p.qNR;
            cp.qSNL = p.qSNL;
            cp.qSNR = p.qSNR;
        }

        for(String key : p.rMap.keySet())
        {
            if (cp.rMap.containsKey(key)) {
                ds_peak p1 =  cp.rMap.get(key);
                ds_peak p2 = p.rMap.get(key);

                if (p2.height > p1.height) {
                    //p2.mStartRT = (p1.mStartRT + p2.mStartRT) / 2;
                    //p2.mEndRT = (p1.mEndRT + p2.mEndRT) / 2;
                    //p2.area = p1.area + p2.area;

                    cp.rMap.remove(key);
                    cp.rMap.put(key, p2);
                } else {
                    //p1.mStartRT = (p1.mStartRT + p2.mStartRT) / 2;
                    //p1.mEndRT = (p1.mEndRT + p2.mEndRT) / 2;
                    //p1.area = p1.area + p2.area;
                }
            } else {
                cp.rMap.put(key, p.rMap.get(key));
            }
        }

        return cp;
    }
}
