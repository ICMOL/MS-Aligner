import java.io.*;
import java.util.*;

public class ds_param {
    public String output;
    public double mzTol;

    public double rtTol;
    public boolean usefdr;
    public double windowsize;
    public int MinChargeState;
    public int MaxChargeState;
    public double MinRTRange;
    public double MaxRTRange;
    public double MinMassRange;
    public double MaxMassRange;
    public double SN;
    public int MinSample;
    public int Level;

    public void readyml(String ymlfile) throws IOException {
        TreeMap<String, Object> ob =new TreeMap<>();
        BufferedReader reader = new BufferedReader(new FileReader(ymlfile));
        String line = reader.readLine();
        while(line != null){
            if(line.contains(":")){
                String header =  line.substring(0, line.indexOf(":")).trim();
                String value = line.substring(line.indexOf(":")+1, line.contains("#")?line.indexOf("#"):line.length()).trim();
                ob.put(header,value.trim());
            }
            line = reader.readLine();
        }
        output = (String)ob.get("output");
        mzTol = Double.parseDouble(String.valueOf(ob.get("mztol")));
        rtTol = Double.parseDouble(String.valueOf(ob.get("rttol")))*60; //convert to seconds
        if(rtTol>0){
            usefdr = false;
        }

        windowsize = Double.parseDouble(String.valueOf(ob.get("WindowSize")))/100;
        MinChargeState = Integer.parseInt(String.valueOf(ob.get("MinChargeState")));
        MaxChargeState = Integer.parseInt(String.valueOf(ob.get("MaxChargeState")));
        MinRTRange = Double.parseDouble(String.valueOf(ob.get("MinRTRange")));
        MaxRTRange = Double.parseDouble(String.valueOf(ob.get("MaxRTRange")));
        MinMassRange = Double.parseDouble(String.valueOf(ob.get("MinMassRange")));
        MaxMassRange = Double.parseDouble(String.valueOf(ob.get("MaxMassRange")));
        //SN = Double.parseDouble(String.valueOf(ob.get("SN")));
        MinSample = Integer.parseInt(String.valueOf(ob.get("MinSample")));
        Level = Integer.parseInt(String.valueOf(ob.get("Level")));
    }


}
