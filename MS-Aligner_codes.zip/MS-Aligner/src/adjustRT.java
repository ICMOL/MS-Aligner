import java.util.List;

public class adjustRT
{
    double _alignAry[];
    double _smoothAry[];

    public adjustRT(double alignAry[], double smoothAry[]){
        this._alignAry = alignAry;
        this._smoothAry = smoothAry;
    }

    public void adjust(List<ds_peak> pLi){
        for(ds_peak p : pLi){
            p.adjustRT = polation(p.mRT);
        }
    }

    public double polation(double rt){
        double adjustRT = 0;
        int start = -1;
        int end = -1;
        if(rt>this._alignAry[0] && rt<this._alignAry[this._alignAry.length-1]){ //perform interpolation
            for(int i=0; i<this._alignAry.length; i++){
                if(this._alignAry[i]>rt){
                    start = i-1;
                    end = i;
                    break;
                }
            }
        }
        else if(rt <= this._alignAry[0]){ //perform extrapolation
            start = 0;
            end = 1;
        }
        else if(rt>=this._alignAry[this._alignAry.length-1]){ //perform extrapolation
            start = this._alignAry.length-2;
            end = this._alignAry.length-1;
        }

        //System.out.println(start+"\t"+end);

        double x1 = this._alignAry[start];
        double y1 = this._smoothAry[start];
        double x2 = this._alignAry[end];
        double y2 = this._smoothAry[end];

        adjustRT = ((y2-y1)/(x2-x1))*(rt-x1)+y1;

        return adjustRT;
    }
}
