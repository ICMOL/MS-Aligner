import org.apache.commons.math3.analysis.interpolation.LoessInterpolator;
import org.w3c.dom.Document;
import org.w3c.dom.Element;


import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.*;
import java.util.stream.Collectors;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;



public class align_rt {
    public void align(ds_param param, TreeMap<String, List<String>> fMap) throws IOException, ParserConfigurationException, TransformerException {
        alignPeak a = new alignPeak(param.mzTol, param.rtTol);

        //region perfrom peak alignment in the replicate level
        TreeMap<String, List<ds_peak>> AlltrMap = new TreeMap<>();
        NumberFormat formatter = null;
        int num=0;
        for (String str : fMap.keySet()) {
            List<String> trLi = fMap.get(str);
            num += trLi.size();
            //1. Select the reference
            int rIndex = functions.SelectReference(trLi);

            //region 2. Set up reference peaks
            a.NewMap();
            List<ds_peak> refpLi = functions.ReadFile(trLi.get(rIndex));  //, wrm
            List<ds_peak> refcpLi = new ArrayList<>();
            for (int i = 0; i < refpLi.size(); i++) {
                if (refpLi.get(i).mCharge > 0) {
                    a.CreateAReference(refpLi.get(i), "r");
                    refcpLi.add(refpLi.get(i));
                }
                //else
                //{
                //    allncpLi.add(refpLi.get(i)); //將 reference中 non-charge的peak加入 allncplist
                //}
            }
            //endregion

            //region 3. perform replicate alignment
            for (int t = 0; t < trLi.size(); t++) {

                System.out.println(trLi.get(t));

                long start = System.currentTimeMillis();
                formatter = new DecimalFormat("#0.00000");

                if (t != rIndex) {
                    List<ds_peak> cpLi = new ArrayList<>(); //儲存 charge 的 peak
                    List<ds_peak> ncpLi = new ArrayList<>(); //儲存 non-charge 的 peak
                    List<ds_peak> lkLi = new ArrayList<>(); //儲存 lankmarks

                    List<ds_peak> pLi = functions.ReadFile(trLi.get(t));  //, wrm
                    for (ds_peak p : pLi) {
                        if (p.mCharge > 0) {
                            cpLi.add(p);
                        } else {
                            ncpLi.add(p);
                        }
                    }

                    //find the landmarks using mztol and rttol
                    for (int i = 0; i < refcpLi.size(); i++) {
                        for (int j = 0; j < cpLi.size(); j++) {
                            double mzdif = Math.abs(cpLi.get(j).mMZ - refcpLi.get(i).mMZ);
                            double rtdif = Math.abs(cpLi.get(j).mRT - refcpLi.get(i).mRT);
                            if ((mzdif <= param.mzTol) && (rtdif <= param.rtTol)) {
                                if (refcpLi.get(i).temP != null) {
                                    double dis = Math.sqrt(Math.pow((refcpLi.get(i).mMZ) - (cpLi.get(j).mMZ), 2) + Math.pow((refcpLi.get(i).mRT - cpLi.get(j).mRT), 2));
                                    double ref_dis = Math.sqrt(Math.pow((refcpLi.get(i).mMZ) - (refcpLi.get(i).temP.mMZ), 2) + Math.pow((refcpLi.get(i).mRT - refcpLi.get(i).temP.mRT), 2));
                                    if (dis < ref_dis) {
                                        refcpLi.get(i).temP = cpLi.get(j);
                                    }
                                } else {
                                    refcpLi.get(i).temP = cpLi.get(j);
                                }
                            }
                        }
                    }
                    for (ds_peak refp : refcpLi) {
                        if (refp.temP != null) {
                            lkLi.add(refp);
                        }
                    }

                    //perform LOWESS regression (Use the landmarks for LOWESS regression and adjust rt shits)
                    List<Double> refLi = new ArrayList<Double>();
                    List<Double> prtLi = new ArrayList<Double>();
                    for (int i = 0; i < lkLi.size(); i++) {
                        if (!refLi.contains(lkLi.get(i).mRT) && !prtLi.contains(lkLi.get(i).temP.mRT)) {
                            refLi.add(lkLi.get(i).mRT);
                            prtLi.add(lkLi.get(i).temP.mRT);
                        }
                    }
                    double refAry[] = new double[refLi.size()];
                    for (int i = 0; i < refLi.size(); i++) {
                        refAry[i] = refLi.get(i);
                    }
                    double prtAry[] = new double[prtLi.size()];
                    for (int i = 0; i < prtLi.size(); i++) {
                        prtAry[i] = prtLi.get(i);
                    }
                    Arrays.sort(refAry);
                    Arrays.sort(prtAry);
                    LoessInterpolator loess = new LoessInterpolator(param.windowsize, 3);
                    double smoothAry[] = loess.smooth(prtAry, refAry);

                    //Adjust the retention time in the aligned peak list
                    adjustRT adj = new adjustRT(prtAry, smoothAry);
                    adj.adjust(cpLi);
                    adj.adjust(ncpLi);

                    //align peaks with charges
                    Collections.sort(cpLi, new Comparator<ds_peak>() {
                        public int compare(ds_peak p1, ds_peak p2) { // sort the peaks on the basis of their intensities in the descending order
                            return Double.compare(p2.height, p1.height);
                        }
                    });



                    for (int j = 0; j < cpLi.size(); j++) {
                        a.align(cpLi.get(j), "r", -1);
                    }

                    for (List<ds_peak> tplist : a.pMap.values()) { //clean up the temPs
                        for (int j = 0; j < tplist.size(); j++) {
                            ds_peak p = tplist.get(j);
                            p.temP = null;
                        }
                    }

                    //align peaks with the charge of 0
                    Collections.sort(ncpLi, new Comparator<ds_peak>() {
                        public int compare(ds_peak p1, ds_peak p2) {
                            return Double.compare(p1.height, p2.height);
                        }
                    });
                    for (int i = 0; i < ncpLi.size(); i++) {
                        a.align(ncpLi.get(i), "r", -1);
                    }

                    long end = System.currentTimeMillis();
                    System.out.println(trLi.get(t) + " finish!\t" + formatter.format((end - start) / (1000d * 60)) + " min.");
                }
            }
            //endregion

            functions.DataIntegration(a.pMap, "r");

            //5. Generate the final peak list
            List<ds_peak> fplist = new ArrayList<>();
            for (List<ds_peak> apd : a.pMap.values()) {
                fplist.addAll(apd);
            }
            a.pMap.clear();
            AlltrMap.put(str, fplist);
        }
        num = num/2;
        //endregion

        //align peaks across samples
        List<ds_peak> allsncplist = new ArrayList<>();
        String refsName = "";
        //region 1. Select a reference
        int maxCount = 0;
        for (String str : AlltrMap.keySet()) {
            int pCount = 0;
            List<ds_peak> plist = AlltrMap.get(str);
            for (int i = 0; i < plist.size(); i++) {
                if (plist.get(i).mCharge >= 1) {
                    pCount += 1;
                }
            }
            if (pCount >= maxCount) {
                maxCount = pCount;
                refsName = str;
            }
        }
        //endregion

        //region 2. perform alignment
        a.NewMap();
        List<ds_peak> refpLi = AlltrMap.get(refsName);
        for (int i = 0; i < refpLi.size(); i++) {
            if (refpLi.get(i).mCharge >= 1) {
                a.CreateAReference(refpLi.get(i), "s");
            } else {
                allsncplist.add(refpLi.get(i));
            }
        }

        List<String> strKeyLi = AlltrMap.keySet().stream().collect(Collectors.toList());
        Collections.sort(strKeyLi);
        for (int i = 0; i < strKeyLi.size(); i++) {
            String sName = strKeyLi.get(i);
            if (sName != refsName) {

                System.out.println(sName);

                List<ds_peak> spLi = AlltrMap.get(strKeyLi.get(i));
                List<ds_peak> cpLi = new ArrayList<>();
                List<ds_peak> ncpLi = new ArrayList<>();
                List<ds_peak> lkLi = new ArrayList<>();

                for (ds_peak p : spLi) {
                    if (p.mCharge > 0) {
                        cpLi.add(p);
                    } else {
                        ncpLi.add(p);
                    }
                }

                //find the landmarks using mzTol and rtTol
                for (int m = 0; m < refpLi.size(); m++) {
                    for (int n = 0; n < cpLi.size(); n++) {
                        double mzdif = Math.abs(cpLi.get(n).mMZ - refpLi.get(m).mMZ);
                        double rtdif = Math.abs(cpLi.get(n).mRT - refpLi.get(m).mRT);
                        if ((mzdif <= param.mzTol) && (rtdif <= param.rtTol)) {
                            if (refpLi.get(m).temP != null) {
                                double dis = Math.sqrt(Math.pow((refpLi.get(m).mMZ) - (cpLi.get(n).mMZ), 2) + Math.pow((refpLi.get(m).mRT - cpLi.get(n).mRT), 2));
                                double ref_dis = Math.sqrt(Math.pow((refpLi.get(m).mMZ) - (refpLi.get(m).temP.mMZ), 2) + Math.pow((refpLi.get(m).mRT - refpLi.get(m).temP.mRT), 2));
                                if (dis < ref_dis) {
                                    refpLi.get(m).temP = cpLi.get(n);
                                }
                            } else {
                                refpLi.get(m).temP = cpLi.get(n);
                            }
                        }
                    }
                }
                for (ds_peak refp : refpLi) {
                    if (refp.temP != null) {
                        lkLi.add(refp);
                    }
                }

                //Use the landmarks for LOWESS regression and adjust rt shits
                //perform LOWESS regression
                List<Double> refLi = new ArrayList<Double>();
                List<Double> prtLi = new ArrayList<Double>();
                for (int j = 0; j < lkLi.size(); j++) {
                    if (!refLi.contains(lkLi.get(j).mRT) && !prtLi.contains(lkLi.get(j).temP.mRT)) {
                        refLi.add(lkLi.get(j).mRT);
                        prtLi.add(lkLi.get(j).temP.mRT);
                    }
                }
                double refAry[] = new double[refLi.size()];
                for (int j = 0; j < refLi.size(); j++) {
                    refAry[j] = refLi.get(j);
                }
                double prtAry[] = new double[prtLi.size()];
                for (int j = 0; j < prtLi.size(); j++) {
                    prtAry[j] = prtLi.get(j);
                }
                Arrays.sort(refAry);
                Arrays.sort(prtAry);
                LoessInterpolator loess = new LoessInterpolator(param.windowsize, 3);
                double smoothAry[] = loess.smooth(prtAry, refAry);

                //Adjust the retention time in the aligned peak list
                adjustRT adj = new adjustRT(prtAry, smoothAry);
                adj.adjust(cpLi);
                adj.adjust(ncpLi);

                Collections.sort(cpLi, new Comparator<ds_peak>() {
                    public int compare(ds_peak p1, ds_peak p2) {
                        return (int) ((p1.height) - (p2.height));
                    }
                });
                for (int j = 0; j < cpLi.size(); j++) {
                    a.align(cpLi.get(j), "s", -1);
                }
                for (List<ds_peak> tpLi : a.pMap.values()) {
                    for (int j = 0; j < tpLi.size(); j++) {
                        ds_peak p = tpLi.get(j);
                        p.temP = null;
                    }
                }

                Collections.sort(ncpLi, new Comparator<ds_peak>() {
                    public int compare(ds_peak p1, ds_peak p2) {
                        return (int) ((p1.height) - (p2.height));
                    }
                });
                for (int j = 0; j < allsncplist.size(); j++) {
                    a.align(allsncplist.get(j), "s", -1);
                }
            }
        }

        //endregion

        functions.DataIntegration(a.pMap, "s");

        System.out.println("starting the second merge");

        //region 3. Second Merge (To avoid the border-line situation)
        //a. 將所有 peak 儲存到 allplist, 並且依其 replicate amount 排序
        List<ds_peak> allpLi = new ArrayList<ds_peak>();
        for (List<ds_peak> cpLi : a.pMap.values()) {
            for (int i = 0; i < cpLi.size(); i++) {
                ds_peak cp = cpLi.get(i);

                int rCount = 0;
                for (ds_peak sp : cp.sMap.values()) {
                    rCount += sp.rMap.size();
                }
                cp.rCount = rCount;
                allpLi.add(cp);
            }
        }
        Collections.sort(allpLi, new Comparator<ds_peak>() {
            public int compare(ds_peak p1, ds_peak p2) {
                return (int) ((p1.rCount) - (p2.rCount));
            }
        });
        a.pMap.clear();

        //b. 重新分群

        mergePeak pm = new mergePeak();
        for (int i = allpLi.size() - 1; i >= 0; i--) {
            pm.pMerge(allpLi.get(i), param.mzTol, -1, param.rtTol);
        }

        //c. 整理資料

        functions.DataIntegration(pm.allpMap, "s");
        allpLi.clear();

        //endregion

        //region 4. Export the aligned result
        //region a. convert the data structure

        for (List<ds_peak> cpLi : pm.allpMap.values()) {
            for (int i = 0; i < cpLi.size(); i++) {
                ds_peak cp = cpLi.get(i);

                int rCount = 0;
                for (ds_peak sp : cp.sMap.values()) {
                    rCount += sp.rMap.size();
                }
                if(rCount >= num){
//                    System.out.println(rCount + ">" + num);
                    cp.rCount = rCount;
                    allpLi.add(cp);}
//                }else System.out.println(rCount + "<" + num);
            }
        }
        a.pMap.clear();

        //endregion

        //region b. export
        File file = new File(param.output + "\\featuretable.tsv");
        BufferedWriter wr = new BufferedWriter(new FileWriter(file));
        wr.write(" MZ \t RT(min.) \t Start_RT(min.) \t End_RT(min.) \t Charge \t IsotopeRatio \t Score \t"); // Score
        if (param.Level == 1) {
            for (String sName : fMap.keySet()) {
                wr.write(sName + "\t");
            }
            wr.newLine();
        } else if (param.Level == 2) {
            for (String sName : fMap.keySet()) {
                List<String> fLi = fMap.get(sName);
                for (String fName : fLi) {
//                    wr.write(fName.substring(fName.lastIndexOf("\\") + 1, fName.lastIndexOf(".")) + "\
                    File sample = new File(fName);
                    String baseName = sample.getName();
                    int dotIndex = baseName.lastIndexOf(".");
                    if (dotIndex != -1) {
                        baseName = baseName.substring(0, dotIndex);
                    }
                    wr.write(baseName + "\t");
                }
            }
            wr.newLine();
        }



        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document document = builder.newDocument();
        Element root = document.createElement("FeatureInformation");
        document.appendChild(root);


        for (ds_peak p : allpLi) {
            boolean is_print = false;

            //check if the peak is detected in at least min_sample
            TreeMap<String, Double> sAbnMap = new TreeMap<String, Double>();
            int count = 0;
            for (String sName : fMap.keySet()) {

                double abn = 0;
                if (p.sMap.containsKey(sName)) {
                    ds_peak sp = p.sMap.get(sName);
                    List<String> fLi = fMap.get(sName);
                    List<Double> abnLi = new ArrayList<Double>();
                    for (String fName : fLi) {

                        if (sp.rMap.containsKey(fName)) {

                            ds_peak rp = sp.rMap.get(fName);
                            abnLi.add(rp.area);
                        }
                    }

                    abn = functions.TakeMedian(abnLi);
                }
                if (abn > 0) {
                    count += 1;
                }
                sAbnMap.put(sName, abn);

            }
            is_print = (count >= param.MinSample) ? true : false;

//          check if the peak is within the given range
            double mass = p.mMZ * (p.mCharge == 0 ? 1 : p.mCharge);
            double rt = p.mRT / 60;
            if ((p.mCharge >= param.MinChargeState) && (p.mCharge <= param.MaxChargeState)
                    && (mass >= param.MinMassRange) && (mass <= param.MaxMassRange)
                    && (rt >= param.MinRTRange) && (rt <= param.MaxRTRange)) {
                is_print = true;
            } else {
                is_print = false;
            }

            //write
            DecimalFormat df2 = new DecimalFormat("#.00");
            DecimalFormat df4 = new DecimalFormat("#.0000");
            DecimalFormat df7 = new DecimalFormat("#.0000000");
            p.mIsoR = Double.parseDouble(df2.format(p.mIsoR));
            p.mMZ =  Double.parseDouble(df4.format(p.mMZ));
            p.mStartRT = Double.parseDouble(df2.format(p.mStartRT/60));
            p.mEndRT = Double.parseDouble(df2.format(p.mEndRT/60));
            p.mRT = Double.parseDouble(df2.format(p.mRT/60));
            p.qScore = Double.parseDouble(df4.format(p.qScore));
            if (param.Level == 1) {
                if (is_print) {
                    wr.write( p.mMZ + "\t" +(p.mRT) + "\t" +(p.mStartRT) + "\t" +(p.mEndRT) + "\t" +p.mCharge + "\t" +p.mIsoR + "\t" +p.qScore + "\t" ); //+ p.qScore + "\t"
                    for (String sName : fMap.keySet()) {
                        wr.write(sAbnMap.get(sName) + "\t");
                    }
                    wr.newLine();
                }
            } else if (param.Level == 2) {
                if (is_print) {
                    //.tsv
                    wr.write(p.mMZ + "\t" +(p.mRT) + "\t" +(p.mStartRT) + "\t" +(p.mEndRT) + "\t" +p.mCharge + "\t" +p.mIsoR + "\t" +p.qScore + "\t" ); //+ p.qScore + "\t"

                    //.xml
                    Element signalElement = document.createElement("signal");
                    root.appendChild(signalElement);
                    creatElementWithTextContent(document, signalElement, "MZ", Double.toString(p.mMZ));
                    creatElementWithTextContent(document, signalElement, "RT", Double.toString(p.mRT));
                    Element signalDataElement = document.createElement("fileData");
                    signalElement.appendChild(signalDataElement);

                    for (String sName : fMap.keySet()) {
                        List<String> fLi = fMap.get(sName);
                        if (p.sMap.containsKey(sName)) {
                            ds_peak sp = p.sMap.get(sName);
                            for (String fName : fLi) {
                                if (sp.rMap.containsKey(fName)) {
                                    //tsv
                                    ds_peak rp = sp.rMap.get(fName);
                                    wr.write(rp.area + "\t");

                                    //xml
                                    Element fileElement = document.createElement("file");
                                    File sample = new File(fName);
                                    String filename = sample.getName();
                                    int dotIndex = filename.lastIndexOf(".");
                                    if (dotIndex != -1) {
                                        filename = filename.substring(0, dotIndex);
                                    }
//                                    String filename = fName.substring(fName.lastIndexOf("\\")+1).split("\\.")[0];;
                                    fileElement.setAttribute("name", filename);
                                    creatElementWithTextContent(document, fileElement , "mz", df7.format(rp.mMZ));
                                    creatElementWithTextContent(document, fileElement , "rt", df2.format(rp.mRT/60));
                                    creatElementWithTextContent(document, fileElement , "Start_RT", df7.format(rp.mStartRT/60));
                                    creatElementWithTextContent(document, fileElement , "End_RT", df7.format(rp.mEndRT/60));
                                    creatElementWithTextContent(document, fileElement , "Shapiro_Wilk_value", df7.format(rp.qsw));
                                    creatElementWithTextContent(document, fileElement , "Slope", df7.format(rp.qslope));
                                    creatElementWithTextContent(document, fileElement , "ZigZagIndex", df7.format(rp.qzigzag));
                                    creatElementWithTextContent(document, fileElement , "Symmetry", df7.format(rp.qsymmetry));
                                    creatElementWithTextContent(document, fileElement , "Sharpness", df7.format(rp.qsharpness));
                                    creatElementWithTextContent(document, fileElement , "TPASR", df7.format(rp.qTPASR));
                                    creatElementWithTextContent(document, fileElement , "ApexMaxBoundary", df7.format(rp.qAMB));
                                    creatElementWithTextContent(document, fileElement , "SignificanceLevel", df7.format(rp.qSL));
                                    creatElementWithTextContent(document, fileElement , "SNR", df7.format(rp.qSNR));

                                    signalDataElement.appendChild(fileElement);
                                } else {
                                    wr.write("0\t");
                                }
                                signalElement.appendChild(signalDataElement);
                                root.appendChild(signalElement);
                            }
                        } else {
                            for (String fName : fLi) {
                                wr.write("0\t");
                            }
                        }
                    }
                    wr.newLine();
                }
            }
//            TransformerFactory transformerFactory = TransformerFactory.newInstance();
//            Transformer transformer = transformerFactory.newTransformer();
//            DOMSource source = new DOMSource(document);
//            StreamResult result = new StreamResult(new File("signals.xml"));
//            transformer.transform(source, result);
        }
        wr.close();


        File metricfile = new File(param.output+ "\\featureInform.xml");
        BufferedWriter writer = new BufferedWriter(new FileWriter(metricfile));

        // 使用 Transformer 輸出 XML 至文件
        Transformer transformer = TransformerFactory.newInstance().newTransformer();
        transformer.setOutputProperty(OutputKeys.INDENT, "yes");

        DOMSource source = new DOMSource(document);
        StreamResult result = new StreamResult(writer);

        try {
            transformer.transform(source, result);
        } catch (TransformerException e) {
            e.printStackTrace();
        }

        writer.close();
        //endregion
    }

    private void creatElementWithTextContent(Document document, Element parent, String tagName, String textContent, String... attributes) {
        Element element = document.createElement(tagName);
        String safeTextContent = textContent.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        element.setTextContent(safeTextContent);
        for (int i = 0; i < attributes.length; i += 2) {
            element.setAttribute(attributes[i], attributes[i + 1]);
        }
        parent.appendChild(element);
    }
}
