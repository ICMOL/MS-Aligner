import java.util.Comparator;

public class ds_statistic implements Comparable<ds_statistic>{
    public double score = -1;
    public double p = -1;
    public double p_minus = -1;
    public double fdr = -1;
    public double smooth_fdr = 0;

    public int decoynum = -1;
    public int targetnum = -1;

    public double slope = -1;
    public String sign = "";

    @Override
    public int compareTo(ds_statistic s) {
        return this.score > s.score ? 1 : (this.score < s.score ? -1 : 0);
    }
}
