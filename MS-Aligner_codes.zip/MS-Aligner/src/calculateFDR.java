import java.io.*;
import java.text.DecimalFormat;
import java.util.*;

public class calculateFDR {
    private int t = 0;

    private double iqr,mid,q3,q1;;

    private void IQR(ArrayList<Double> scoreLi){
        if(scoreLi.size()%2==0) {
            mid=(scoreLi.get((scoreLi.size())/2)+scoreLi.get((scoreLi.size())/2-1))/2;
        }else {
            mid=scoreLi.get((scoreLi.size()-1)/2);
        }
        if(scoreLi.size()%4<2){
            q1=(scoreLi.get(scoreLi.size()/4)*3+scoreLi.get(scoreLi.size()/4-1))/4;
        }else{
            q1=(scoreLi.get(scoreLi.size()/4)+scoreLi.get(scoreLi.size()/4-1)*3)/4;
        }
        if((scoreLi.size()*3)%4<2){
            q3=((scoreLi.get(scoreLi.size()*3/4)+scoreLi.get(scoreLi.size()*3/4-1)*3)/4);
        }else{
            q3=((scoreLi.get(scoreLi.size()*3/4)*3+scoreLi.get(scoreLi.size()*3/4-1))/4);
        }
        iqr = q3-q1;
    }

    public double FindScoreCutoff(List<ds_peak> refcpLi, List<ds_peak> cpLi, double mztol) throws IOException {
        double fdrscore = 0d;
        double bin = 1000;
        double min_score = 0;
        int topN = 100;
        DecimalFormat df = new DecimalFormat("#######.####");
        double window = 10;

        ArrayList<Double> targetLi = new ArrayList<>(); //list for targets
        ArrayList<Double> decoyLi = new ArrayList<>(); //List for decoys
        ArrayList<Double> scoreLi = new ArrayList<>(); //list for targets+decoys
        //region 1. Calculate score

        for(int i=0; i<refcpLi.size(); i++) {
            ArrayList<ds_peak> data = new ArrayList<>();
            for (int j = 0; j < cpLi.size(); j++) {
                if(Math.abs(refcpLi.get(i).mMZ- cpLi.get(j).mMZ) <= mztol) {
                    //if(true){
                    //double dis = Math.sqrt(Math.pow((refcpLi.get(i).mMZ) - (cpLi.get(j).mMZ), 2) + Math.pow((refcpLi.get(i).mRT - cpLi.get(j).mRT), 2));
                    double dis = refcpLi.get(i).mRT - cpLi.get(j).mRT;
                    dis = (dis==0) ? 9999 : 1 / dis;
                    if(dis>min_score){
                        cpLi.get(j).score = dis;
                        data.add(cpLi.get(j));
                    }
                }
            }

            if(data.size()>0)
            {
                Collections.sort(data,new Comparator<ds_peak>(){//sort data in the descending order
                    public int compare(ds_peak p1, ds_peak p2) {
                        return -((p1.score).compareTo(p2.score));
                    }
                });

                //TreeMap<Float, Double> tMap = new TreeMap<Float, Double>();
                List<ds_peak> pLi = new ArrayList<ds_peak>();

                for(int k=0; k<data.size(); k++) {
                    if(k<topN){
                        double score = Double.parseDouble(df.format((data.get(k).score)));
                        if(score>0){
                            if(k==0) {
                                targetLi.add(score);
                                refcpLi.get(i).targetLi.add(data.get(k));
                            }
                            else{
                                decoyLi.add(score);
                                refcpLi.get(i).decoyLi.add(data.get(k));
                            }
                        }

                    }
                }
            }

        }
        scoreLi.addAll(targetLi);
        scoreLi.addAll(decoyLi);

        //endregion

        //region 2. Remove outliers

        targetLi = RemoveOutlier(targetLi);
        decoyLi = RemoveOutlier(decoyLi);
        scoreLi = RemoveOutlier(scoreLi);

//        IQR(scoreLi);
//        ArrayList<Double> targettmpLi = new ArrayList<>(); //to store the targeted scores
//        for(double t : targetLi){
//            if (t < mid + (iqr * 1.5) && t > mid - (iqr * 1.5)){
//                targettmpLi.add(t);
//            }
//        }
//        targetLi.clear();
//        targetLi.addAll(targettmpLi);
//
//        ArrayList<Double> decoytmpLi = new ArrayList<>();
//        for(double d : decoyLi){
//            if (d < mid + (iqr * 1.5) && d > mid - (iqr * 1.5)){
//                decoytmpLi.add(d);
//            }
//        }
//        decoyLi.clear();
//        decoyLi.addAll(decoytmpLi);
//
//        ArrayList<Double> scoretmpLi = new ArrayList<>();
//        for(double s : scoreLi){
//            if (s < mid + (iqr * 1.5) && s > mid - (iqr * 1.5)){
//                scoretmpLi.add(s);
//                max_score = s>max_score? s:max_score;
//            }
//        }
//        scoreLi.clear();
//        scoreLi.addAll(scoretmpLi);

        //endregion

        Collections.sort(scoreLi);
        double max_score=scoreLi.get(scoreLi.size()-1);

//        t+=1;
//        BufferedWriter wr = new BufferedWriter(new FileWriter("D:\\08_MS-Aligner\\analysis\\cguQC\\score_"+t+".tsv"));
//        for(double s : scoreLi){
//            wr.write(s+""); wr.newLine();
//        }
//        wr.close();



        //region 3. Run EM and find pi0 and pi1

        performEM performEm = new performEM();
        performEm.EM(scoreLi);
        double pi1 = 0.0d;
        if(performEm.miu[0]> performEm.miu[1]) {
            pi1 = performEm.pi[0];
        }else{
            pi1 = performEm.pi[1];
        }

        //endregion

        TreeMap<Double, int[]> hisMap = new TreeMap<Double, int[]>();
        //region 4. Construct score histogram (bins = 1000)

        Collections.sort(decoyLi);
        df = new DecimalFormat("#######.########");
        double binwidth = Double.parseDouble(df.format((max_score-min_score)/bin));
        double start = min_score;
        double end = start+binwidth;
        int count = 0;
        for(double score : decoyLi){
            if((score >= start)&&(score<end)){
                count += 1;
            }
            else{
                int[] cAry = new int[2];
                cAry[0] = count;
                hisMap.put(start,cAry);
                start = end;
                end += binwidth;
                count = 1;
            }
        }


        Collections.sort(targetLi);
        start = min_score;
        end = start+binwidth;
        count = 0;
        for(double score : targetLi){
            if((score >= start)&&(score<end)){
                count += 1;
            }
            else{
                if(hisMap.containsKey(start)){
                    int[] cAry = hisMap.get(start);
                    cAry[1] = count;
                }
                else{
                    int[] cAry = new int[2];
                    cAry[1] = count;
                    hisMap.put(start,cAry);
                }
                start = end;
                end += binwidth;
                count = 1;
            }
        }

        //endregion

        //region 5. Calculate p-value and FDR
        //TreeMap<Double, Double> pMap = new TreeMap<Double, Double>();
        List<ds_statistic> statLi = new ArrayList<ds_statistic>();
        for(double score : hisMap.keySet()){
            int[] cAry = hisMap.get(score);

            ds_statistic stat = new ds_statistic();
            double f = ((1-pi1)*cAry[0])+(pi1*cAry[1]);
            stat.score = score;
            stat.p = (f>0) ? (pi1*cAry[1])/f : 0;
            stat.p_minus = 1 - stat.p;
            stat.decoynum = cAry[0];
            stat.targetnum = cAry[1];

            statLi.add(stat);
        }

        //endregion

        //region 6. Calculate FDR

        Collections.sort(statLi, new Comparator<ds_statistic>(){
            public int compare(ds_statistic s1, ds_statistic s2)
            {
                return s1.p_minus > s2.p_minus ? 1 : (s1.p_minus < s2.p_minus ? -1 : 0);
            }
        });
        for(int i=0; i<statLi.size(); i++){
            double numerator =0;
            double denominator = 0;
            for(int j=0; j<=i; j++){
                numerator += statLi.get(j).p_minus;
                denominator += statLi.get(j).targetnum;
            }
            statLi.get(i).fdr = numerator/denominator;
        }

        //smooth fdr distribution
        int window_half = (int) window/2;
        for(int i=0; i<statLi.size(); i++){
            int window_start = (i-window_half)>=0 ? (i-window_half) : i;
            int window_end = (statLi.size()-i)>=window_half? (i+window_half) : (statLi.size()-i);
            for(int j=window_start; j<window_end; j++){
                statLi.get(i).smooth_fdr += statLi.get(j).fdr;
            }
            statLi.get(i).smooth_fdr /= (window_end-window_start+1);
        }

        //endregion

        //region 7. Find the score threshold

        for(int i=1; i<statLi.size()-1; i++){
            statLi.get(i).slope = statLi.get(i+1).smooth_fdr - statLi.get(i).smooth_fdr;
            if(statLi.get(i).slope>=0){
                statLi.get(i).sign = "+";
            }
            else{
                statLi.get(i).sign = "-";
            }
        }

        double percentage = 0.6; //over 60% signs are consistent
        for(int i=0; i<statLi.size(); i++){
            if(statLi.get(i).sign=="-"){
                double lpercent = 0;
                for(int j=0; j<window; j++){
                    int index = i-j;
                    lpercent += (index>=0) ? (statLi.get(index).sign=="+"?1:0) : 0;
                }
                lpercent/=window;

                double rpercent = 0;
                for(int j=0; j<window; j++){
                    int index = i+j;
                    rpercent += (index<statLi.size())? (statLi.get(index).sign=="-"?1:0) : 0;
                }
                rpercent/=window;

                if((lpercent>=percentage) &&(rpercent>=percentage)){
                    fdrscore = statLi.get(i+1).score;
                }
            }
        }

        //endregion

        //print out the statistic
//        t+=1;
//        BufferedWriter wr = new BufferedWriter(new FileWriter("D:\\08_MS-Aligner\\analysis\\cguQC\\static_"+t+".tsv"));
//        wr.write("score \t decoy \t target \t p \t 1-p \t fdr \t smooth_fdr \t sign"); wr.newLine();
//        for(int i=0; i<statLi.size(); i++){
//            wr.write(statLi.get(i).score + "\t"
//                    + statLi.get(i).decoynum + "\t"
//                    + statLi.get(i).targetnum + "\t"
//                    + statLi.get(i).p + "\t"
//                    + statLi.get(i).p_minus + "\t"
//                    + statLi.get(i).fdr + "\t"
//                    + statLi.get(i).smooth_fdr + "\t"
//                    + statLi.get(i).sign);
//            wr.newLine();
//        }
//        wr.close();

        return fdrscore;
    }

    private static ArrayList<Double> RemoveOutlier(ArrayList<Double> scoreLi){
        double min = 0.1;
        double max = 10;
        ArrayList<Double> tmpLi = new ArrayList<Double>();

        for(double value : scoreLi){
            if((value>=min) && (value<=max)){
                tmpLi.add(value);
            }
        }

        return tmpLi;
    }
}
