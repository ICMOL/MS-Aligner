## **Introduction**
A software tool designed to perform peak alignment for both proteomics and metabolomics data generated from LC-MS/MS platforms.

## **System Requirement**
* [Java SE Runtime Environment 8(or above)](https://www.oracle.com/tw/java/technologies/javase/javase8-archive-downloads.html) is required to be installed prior to use AutoMod.

## **How to use**
### **step 1. Set up parameter**
1. The folder path for analyzed files.
2. The path to the YAML file storing the parameters.
   
      Open the 'param.yml' file and edit the paramters if necessary.
      | Name | Default Values | Comments |
    | :---          |     :---:      |        :---   |
    | mztol | 0.05  | m/z tolerance(unit : Da.). |
      |rttol |0.5|retention time tolerance(unit : min.) If the retention time and m/z differences of two features across different samples fall within this range, they are likely candidates for the same feature.|
      |output| | output folder path|
      |WindowSize|20|window size for LOWESS regressions|
      |MinChargeState|1|minimum charge state|
      |MaxChargeState|4|maximum charge state|
      |MinRTRange|0.0|minimum retention time (unit: minute)|
      |MaxRTRange|9999.0|	maximum retention time (unit: minute)|
      |MinMassRange|0.0|minimum mass|
      |MaxMassRange|9999.0|maximum mass|
      |MinSample|1|minimum number of samples|
      |Level|2|export the result in two levels, 1:sample level; 2: replicate level|

### **step 2. Execute the command**
As an example
required documents： 
1. YAML file："D:\param.yml"
2. analyzad files (folder path)："D:\analyzed files"
> java -jar MS-Aligner.jar "D:\param.yml" "D:\analyzed files"

### **step 3. Output**
1. peakList.tsv：A table with detected metabolite features in rows and samples in columns
2. metricList.tsv：A table with nine metrics extracts from each file produced by [MS-Picker](https://github.com/ICMOL/MS-Picker).
   This file allows you to view the distribution of each metric in [DeNox](https://github.com/ICMOL/source-DeNox).
